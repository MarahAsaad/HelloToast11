#Add project specific ProGuard rules here.
#You can control the set of applied configuration files using the
#proguarFiles setting in build.gradle.
#
#http://developer.android.com/gruide/developing/tools/proguard.html
#if your project uses WebView with JS, uncomment the following
#and specify the fully qualified class name to the JavaScript interface
#class:
#-Keepclassmembers class fqcn.of.javascript.interface.for.webview{
# public*;
#}
#Uncomment this to preserve the line number information for
#debugging stack traces.
#-keepattributes SourceFile,LineNumberTable
#If you keep the line number information, uncomment this to
#hide the original source file name.
#-renamesourcefileattribute SourceFile