package com.example.hellotoast11;
import android.app.Activity;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.example.hellotoast11.databinding.ActivityMainBinding;

public class MainActivity extends android.app.Activity  {
    private int count=0;
    private TextView textDisplayCount;
    private Button buttonCount;
    private Button buttonZero;
    @Override
    protected void  onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        textDisplayCount=findViewById(R.id.textDisplayCount);
        buttonCount=findViewById(R.id.button_count);
        buttonZero=findViewById(R.id.button_zero);
        buttonZero.setBackgroundTintList(ColorStateList.valueOf(Color.GRAY));
    }
    public void show_toast(View view){
        Toast.makeText(view.getContext(), "Hello Toast",Toast.LENGTH_SHORT).show();
    }
    public void increase_count(View view) {
        count++;
        textDisplayCount.setText(String.valueOf(count));
        if (count % 2 == 1) {
            buttonCount.setBackgroundTintList(ColorStateList.valueOf(Color.GREEN));
        } else {
            buttonCount.setBackgroundTintList(ColorStateList.valueOf(Color.BLUE));
        }
        buttonZero.setBackgroundTintList(ColorStateList.valueOf(Color.rgb(255,165,0)));
    }
    public void showZero(View view){
        count=0;
        textDisplayCount.setText(String.valueOf(count));
        buttonZero.setBackgroundTintList(ColorStateList.valueOf(Color.GRAY));
    }

    public Button findViewById(int buttonCount) {
        return null;
    }

    public void setContentView(int activityMain) {

    }

}