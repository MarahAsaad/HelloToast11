package AppCompatActivity;

import android.os.Bundle;

public abstract class AppCopatActiivity {
    protected void onCreate(Bundle savedInstanceState) {
    }
}
