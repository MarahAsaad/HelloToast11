plugins {
    alias(libs.plugins.android.application)
}

android {
    namespace = "com.example.hellotoast11"
    compileSdk {
        version = release(35)
    }

    defaultConfig {
        applicationId = "com.example.hellotoast11"
        minSdk = 24
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
    }

    buildTypes {
        release {
            isMinifyEnabled=false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),"proguard-rules.pro"
            )
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_11
        targetCompatibility = JavaVersion.VERSION_11
    }
    buildFeatures{
        viewBinding=true
    }
}

dependencies {
   implementation(libs.androidx.appcompat)
    implementation(libs.androidx.core)
    implementation(libs.androidx.junit)
    implementation(libs.androidx.monitor)
    implementation(libs.appcompat)
    implementation(libs.material)
    implementation(libs.androidx.activity.ktx)
    implementation(libs.androidx.constraintlayout)
    testImplementation(libs.junit)
    androidTestImplementation(libs.androidx.espresso.core)
}